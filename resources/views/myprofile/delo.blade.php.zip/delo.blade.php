    @extends('layouts.frontend.app')
@section('title','Люди для людей')
<meta name="description" content="Тест">
        <meta name="keywords" content="">
@push('css')
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
@endpush
@section('content')
          <main class="col-xs-12">
              
              <div class="sm-breadcrumb">
    <ol class="breadcrumb">
        <li><a href="https://myldl.ru/">Главная</a></li><li><a href="https://myldl.ru/affairs">Дела</a></li><li class="active">Спасение из сугроба</li>    </ol>
</div><!-- діалог -->
<link href="https://myldl.ru/application/views/front/datepicker/jquery-ui.css" rel="stylesheet">
<script src="https://myldl.ru/application/views/front/datepicker/jquery-ui.js"></script>
<!-- діалог end -->

<!-- Add fancyBox main JS and CSS files -->
<script type="text/javascript" src="https://myldl.ru/application/views/front/fancy_box/jquery.fancybox.js?v=2.1.5"></script>
<link rel="stylesheet" type="text/css" href="https://myldl.ru/application/views/front/fancy_box/jquery.fancybox.css?v=2.1.5" media="screen" />

<div id="showcontact">
    <h2 class="text-center">Авторизируйтесь для<br>просмотра данных</h2>
    <form action="https://myldl.ru/auth/login?backurl=usluga/" class="form" role="form" method="post" accept-charset="UTF-8" id="login-nav LoginForm">
        <input name="email" type="email" class="form-control email" id="exampleInputEmail2" placeholder="| Логин / E-mail" required>
        <input name="passw" type="password" class="form-control password" id="exampleInputPassword2" placeholder="| Пароль" required>
        <div class="checkbox">
            <label>
                <input type="checkbox"> Запомнить меня
            </label>
        </div>
        <input type="hidden" id="hashLoginID" name="ci_csrf_token" value="">
        <button type="submit" class="btn btn-success btn-block">Войти</button>
        <a class="text-center btn-reg a-btn" href="/auth/register">Новый пользователь?</a>
    </form>
</div>

<script>
    $(document).ready(function() {
        load_comment();

 function load_comment()
 {
     var delo_id=$('#delo_id').val();
  $.ajax({
   url:"/test/coment/get",
   method:"POST",
   
   data:{'delo_id':delo_id},
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
   success:function(data)
   {
    $('#display_comment').html(data);
   }
  })
 }
        
        
        $('.fancybox').fancybox();
        //Media helper. Group items, disable animations, hide arrows, enable media and button helpers.

         $('.fancybox-media').attr('rel', 'media-gallery').fancybox({
             openEffect : 'none',
             closeEffect : 'none',
             prevEffect : 'none',
             nextEffect : 'none',
             arrows : false,
             helpers : {
             media : {},
             buttons : {}
             }
         });

        //$('#action').hide(0);
        $('#show_hide').click(function(event){
            $('#action').slideToggle('slow');
        });

        $('.del').click(function(){
            $.ajax({
                type:"POST",
                url: "/main/ajax_del_uchasnik_delo",
                data: {
                    delo_id : delo_id,
                    user:$(this).attr('user_id'),
                    tkn_name : $.cookie(tkn_val)
                },
                dataType: "html",
                success: function(msg){
                    alert(msg);
                    location.reload(0);
                }
            });
            return false;
        });

        // удаления запрашиваемое Дело
        $('.del_delo').click(function(){
            if (confirm("Удалить это дело?")) {
                document.location.href = "/main/del_delo/"+$(this).attr("delo_id");
            }
            return false;
        });

    });
</script>

<div id="dialog2" title="Пожаловаться на дело" style="display: none">
    Вы можете отправить администратору жалобу на дело "Спасение из сугроба":<br /><br />
    <div class="row">
        <label>Текст жалобы</label>
        <textarea id="text_appeal"></textarea>
    </div>
    <div class="btn-group">
        <button type="button" class="btn add btn-green">Отправить</button>
        <a class="a-btn" onclick="$.fancybox.close();">Закрыть</a>
    </div>
</div>
<script>
    $('#dialog2 button').click(function () {
        $.post(
            "/main/ajax_send_appeal_delo",
            {
                id_dela : delo_id,
                text: $("#text_appeal").val(),
                tkn_name : $.cookie(tkn_val)
            }
        );
        $('#dialog2').html("<center><br /><br /><h3>Ваша жалоба отправлена администратору !</h3><br /><br /></center>");
        setTimeout(function() {
            $.fancybox.close();
            location.reload(0);
        },
        800);
    });
</script>
<div id="dialog3" title="Стать учасником" style="display: none">
    Вы хотите стать участником данного дела?<br /><br />
    <div class="btn-group">
        <button type="button" class="btn add btn-green">Да</button>
        <a class="a-btn" onclick="$.fancybox.close();">Нет</a>
    </div>
</div>
<script>
    $('#dialog3 button').click(function () {
        $.ajax({
            type: "POST",
            url: "/main/ajax_stat_uchasnikom_delo",
            data: {
                delo_id : delo_id,
                tkn_name : $.cookie(tkn_val)
            },
            dataType: "html",
            success: function(msg){
                if(msg=="ok") {
                    $('#dialog3').html("<center><br /><br /><h3>Вы добавлены как участник !</h3><br /><br /></center>");
                }
                if(msg=="error") {
                    $('#dialog3').html("<center><br /><br /><h3>Вы уже являетесь участником этого дела !</h3><br /><br /></center>");
                }
                if(msg=="auth") {
                    $('#dialog3').html("<center><br /><br /><h3>Войдите на сайт под своей учетной записью !</h3><br /><br /></center>");
                }
            }
        });
        setTimeout(function() {
            $.fancybox.close();
            location.reload(0);
        },
        800);
    });
</script>
<div id="dialog4" title="Избранное" style="display: none">
    Добавить это дело в избранные дела?<br /><br />
    <div class="btn-group">
        <button type="button" class="btn add btn-green">Да</button>
        <a class="a-btn" onclick="$.fancybox.close();">Нет</a>
    </div>
</div>
<script>
    $('#dialog4 button').click(function () {
        $.ajax({
            type: "POST",
            url: "/main/ajax_add_to_izbrannoe",
            data: {
                delo_id : delo_id,
                tkn_name : $.cookie(tkn_val)
            },
            dataType: "html",
            success: function(msg){
                if(msg=="ok") {
                    $('#dialog4').html("<center><br /><br /><h3>Дедо добавлено в избранное !</h3><br /><br /></center>");
                }
                if(msg=="error") {
                    $('#dialog4').html("<center><br /><br /><h3>Это дело уже в избранном !</h3><br /><br /></center>");
                }
                if(msg=="auth") {
                    $('#dialog4').html("<center><br /><br /><h3>Войдите на сайт под своей учетной записью !</h3><br /><br /></center>");
                }
            }
        });
        setTimeout(function() {
                $.fancybox.close();
            location.reload(0);
        },
        800);
    });
</script>
<div id="dialog5" title="Стать учасником" style="display: none">
    Для индивидуального дела не предполагается участие других людей<br /><br />
</div>
<script type="text/javascript">
    var delo_id = '27';
    var tkn_name = 'ci_csrf_token';
    var tkn_val  = 'hash_cookie_id';
</script>

<section>
    <div class="advert advert-inner">
        <div class="left">
            <div class="date"><span>{{ Carbon\Carbon::parse($delo->created_at)->format('d.m.Y') }}</span></div>
            <div class="title">
                <h1>{{$delo->nazva}}</h1>
            </div>

            <div class="adv-inner-body news-inner-body">
	                            <div class="adv-inner-left inner-100">
                    <div class="awa-226 bg" style="background-image: url(https://myldl.ru/static/images/noimg.png);"></div>
                    <div class="deal-become-member show-xs">
                                                    <a href="#dialog5" data-height="160" class="fancybox mbtn to_relation green" style="font-size:14px;">Стать участником</a>
                            <a href="#dialog4" class="fancybox mbtn" data-width="363" data-height="150" style="font-size:14px;">В избранное</a>
                                                <a href="#dialog2" class="fancybox mbtn" style="font-size:14px;">Пожаловаться</a>
                    </div>

                    <div class="profile-info" style="float: left;">
                        <p><b>Инициатор</b>: <a href="https://myldl.ru/user/20266"></a></p>
                        <p><b>Дата открытия</b>: <span>{{ Carbon\Carbon::parse($delo->created_at)->format('d.m.Y') }}</span></p>
                        <p class="profile-info-p"><b>Тип</b>:{{$delo->status==1?'Индивидуальное':'Коллективное'}}</p>
                        <p><b>Текущий статус</b>:{{$delo->status==0?'Закрыто':'Открыто'}} <span></span></p>
                    </div>
                    <style>
                        .profile-info>p {
                            margin-bottom: 8px;
                            margin-top: 0;
                        }
                        .profile-info {
                            width: 100%;
                        }
                        @media (min-width: 470px) {
                            .profile-info {
                                width: calc(100% - 246px);
                            }
                        }
                        @media (max-width: 919px) {
                            section .advert-inner .left .news-inner-body .deal-become-member {
                                float: left;
                            }
                        }
                        @media (min-width: 920px) {
                            .profile-info {
                                width: calc(100% - 406px);
                            }
                        }
                    </style>

                    <div class="deal-become-member hide-xs">
		                                            <a href="#dialog5" data-height="160" class="fancybox mbtn to_relation green" style="font-size:14px;">Стать участником</a>
                            <a href="#dialog4" class="fancybox mbtn" data-width="363" data-height="150" style="font-size:14px;">В избранное</a>
		                                        <a href="#dialog2" class="fancybox mbtn">Пожаловаться</a>
                    </div>
                </div>

                <div class="adv-inner-desc">
                    <div class="profile-info2" style="margin-top: 0">
                        <p><b>Город</b>: <span>{{$delo->city}}</span></p>
                        <p><b>Бюджет</b>:{{$delo->bydzet}} <span></span></p>
                        <p><b>Затраченное время</b>: <span>{{$delo->vremya}}</span></p>
                    </div>
                    <b style="font-size: 16px">Описание</b>: {{$delo->opisanie}}
                    <div class="profile-info2">
                        <p><b>Участники</b>: <span>{{$delo->user->count()}}</span></p>
                        <p><b>Эффект</b>: <span>{{$delo->effekt}}</span></p>
                        <p><b>Для чего это делалось</b>: {{$delo->dlya_chego}}<span></span></p>
                                            </div>
                    <style>
                        section .advert-inner .left .adv-inner-body .adv-inner-desc .profile-info2 {
                            margin-top: 30px;
                        }
                        section .advert-inner .left .adv-inner-body .adv-inner-desc .profile-info2 p {
                            font-size: 16px;
                            margin-bottom: 0;
                        }
                    </style>
                </div>

                <div class="news-views" style="margin-top: 25px;">
	                
<img src="https://myldl.ru/static/images/like.png" class="stat-item thumbs-up like" section_id="12" post_id="27"/>
<span class="like_c">5</span>
<img src="https://myldl.ru/static/images/dislike.png" class="stat-item thumbs-down dislike" section_id="12" post_id="27"/>
<span class="dislike_c">0</span>                    <img src="https://myldl.ru/static/images/comments.png"/>
                    <span>1</span>
                    <img src="https://myldl.ru/static/images/views.png"/>
                    <span>0</span>
                </div>
            </div>
            <div class="info-block">
                <p><span>Фото:</span> 0</p>
		                        <p><span>Видео:</span> 0</p>
                <div class="row container-fluid">
                    <div class="video clearfix">
                        <ul class="gallery">
					        						        					                                </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="right">
            <span class="title">Последние дела</span>
            <div class="advert-body">
	                                <div class="article-info">
                        <div class="article-subtitle">
                            <div class="date"><span>29.01</span></div>
                            <a href="https://myldl.ru/delo/104">Поддержим Демида</a>
                        </div>
                    </div>
	                                <div class="article-info">
                        <div class="article-subtitle">
                            <div class="date"><span>15.08</span></div>
                            <a href="https://myldl.ru/delo/74">ПОДГОТОВКА К ЗИМЕ...</a>
                        </div>
                    </div>
	                                <div class="article-info">
                        <div class="article-subtitle">
                            <div class="date"><span>20.03</span></div>
                            <a href="https://myldl.ru/delo/71">помощь больному</a>
                        </div>
                    </div>
	                                <div class="article-info">
                        <div class="article-subtitle">
                            <div class="date"><span>20.03</span></div>
                            <a href="https://myldl.ru/delo/70">помощь подруге</a>
                        </div>
                    </div>
	                                <div class="article-info">
                        <div class="article-subtitle">
                            <div class="date"><span>20.03</span></div>
                            <a href="https://myldl.ru/delo/69">Помощь утопающему</a>
                        </div>
                    </div>
	                            <div class="article-info">
                    <a href="https://myldl.ru/dela" class="page-button">Показать еще</a>
                </div>
            </div>
        </div>

        <div class="adv-comments last-section" style="margin-bottom: 25px;">
            <span class="title">Участники {{$delo->user->count()}}</span>
            <div class="slider">
                <div class="button">
                    <button id="owl-uchasniki-left"><</button>
                </div>
                <div class="slider-body">
                    <div class="owl-carousel owl-theme" id="owl-uchasniki">
	                                       @foreach($delo->user as $user)
	                                        <div class="person">
	                                            @if(isset($user->person->avatar))
                                                            <img src="{{asset('/storage/avatar/'.$user->person->avatar)}}"/>
                                                            @endif
                                                        <a href="https://myldl.ru/user/8" class="person-name">{{$user->name}}</a>
                        </div>
                        @endforeach
                        
	                                    </div>
                </div>
                <div class="button">
                    <button id="owl-uchasniki-right">></button>
                </div>
            </div>
        </div>

	    
<!-- ---------------- Comments ---------------- -->

<script src="https://myldl.ru/application/views/front/js/LDL_Comments.js"></script>


<script type="text/javascript">
$(document).ready(function(){
	LDL_Comments.setSmilesUrl('https://myldl.ru/application/views/front/images/smiles/');  // url post
	LDL_Comments.setSendUrl('https://myldl.ru/ajax/ajax_comments');         // url post
	LDL_Comments.setUserUrl('https://myldl.ru/main/user/');                 // url user
	LDL_Comments.setAvatarUrl('https://myldl.ru/images/avatar/');        // url avatar
	LDL_Comments.setUserId(1);     // status current user
	LDL_Comments.setUserName('admin');                          // user name
	LDL_Comments.setUserAvatar('5876494009871b6eda73d243524b8863_thumb.jpg');                      // user avatar
	LDL_Comments.setSectionId(12);                    // section ID
	LDL_Comments.setPostId(27);                                // post ID
	LDL_Comments.setHashCookieID('hash_cookie_id'); // name Cookie Hash ID
	LDL_Comments.init();                                                    // START JS

    $('.BDC_CaptchaImageDiv, .BDC_CaptchaDiv').removeAttr('style');
    $('#CommentsCaptcha_ReloadIcon').attr('src', '/static/images/refresh.png');
    $('#CommentsCaptcha_SoundIcon').attr('src', '/static/images/voice-recording.png');
});
 </script>



<div class="adv-comments">
    <div class="title">Комментарии (1)</div>
        <br />
  <br />
  <div class="container" style="width:80%">
      
   <form  id="comment_form">
    @guest
    <div class="form-group">
     <input type="text" name="comment_name" id="comment_name" class="form-control" placeholder="Введите имя:" />
    </div>
    @endguest
    <div class="form-group">
     <textarea name="comment_content" id="comment_content" class="form-control" placeholder="Введите комментарий" rows="5"></textarea>
    </div>
    <div class="form-group">
     <input type="hidden" name="comment_id" id="comment_id" value="0" />
     <input type="hidden" id="delo_id" name="delo_id" value="{{$delo->id}}"/>
     <input type="submit" name="submit" id="submit" class="btn btn-info" value="Submit" />
    </div>
   </form>
   <span id="comment_message"></span>
   <br />
   <div id="display_comment"></div>
  </div>

        
        
        
        
        
           </div>
</section>
    <script>
        $(document).ready(function () {
            $('.fancybox').fancybox({
                'width':500,
                'height': 400,
                'autoDimensions': false,
                'autoSize':false
            });
        });
        </script>
        
            @push('js')
        
         @endpush

@endsection